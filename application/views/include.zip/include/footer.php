<div class="clear"></div>
			<?php if($this->uri->segment(1)=='home' || $this->uri->segment(1)==''):?>
				<div class="working_committee"></div><br />
            <?php endif; ?>
            <div class="quick_link"><a href="<?php echo site_url('home/'); ?>">Home</a> <a href="<?php echo site_url('rules/'); ?>">Rule</a> <a href="<?php echo site_url('issues/'); ?>">Issues</a> <a href="<?php echo site_url('notice/'); ?>">Notice Board</a> <a href="<?php echo site_url('gallery/'); ?>">Gallary</a> <a href="<?php echo site_url('contact/'); ?>">Contact Us</a></div>
            <div class="clear"></div>
 </div>
 
      </div>
        <div class="clear"></div>
<div id="footer">
  <div class="footer_upper">Disclaimer :The National Institute of Science and Communication and Information Resources (CSIR) has awarded the Journal ISSN Nos. as ISSN 2249 – 3921 (for the Print Version)
and ISSN 2249 – 4316 (for the On-line Version). The editor shall in no way be responsible for the views expressed by the authors in their articles.</div>
	<div class="footer_lower">Site maintained by Provati Digitrix</div><div class="footer_lower">Last Updated: 4'th May 2012</div><div class="footer_lower">Copyright @ IJSS 2012</div>
	
</div>
  </div>
 
</div>

</body>
</html>
