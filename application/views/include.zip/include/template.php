<?php $this->load->view('include/header'); ?>

	<!--end header-->
            <div id="middle_col_big">
              <div class="page_header">
                <div class="left_curve"></div><div class="rules_title">General General General General General</div><div class="right_curve"></div>
              </div>
              <div class="inner">
              	<div class="text">
                	<div class="head_icon"><img src="<?php echo base_url(); ?>assats/looks/images/content_icon.png" width="110" height="31" /></div>
                	<p> <!--page content-->
            	<?php //$this->load->view($content_for_layout); ?>
            <!--end page content-->
            IJSS, The Indian Journal of Spatial Science is a publication of the Association of the Spatial Scientists of India with head quarter currently at the Department of Geography, Presidency University (formerly College), Kolkata. Its editorial board reserves the right to revise or modify articles to conform to the journal's style. The views expressed in the article will however, remain the opinion of the authors, and the editorial board accepts no responsibility for these. Articles which do not strictly abide by the instructions mentioned here are likely to be rejected without further review. All costs towards review, editing, composition, website management, and etc shall be borne by the author (s). All payments hould be made in advance only after intimation through e-mail by the President, Geographical Institute. </p>
              	</div>
              </div>
            </div>
           
            
            
            <!--footer portion-->
		<?php $this->load->view('include/footer');?>
        	<!--end footer portion-->