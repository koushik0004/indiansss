<?php $this->load->view('include/header'); ?>

	<!--end header-->
            <div id="middle_col_big" style="background-color:#C0C0C0; padding:69px 0 69px 108px; width:861px;">
              
              	<div class="contact_us_bg">
                <table width="100%" border="0" style="color:#00576d; font-family:Arial, Helvetica, sans-serif; font-size:14px;">
                  <tr style="font-size:16px; font-weight:bold;">
                    <td align="left" valign="top">Editor<br /></td>
                    <td align="left" valign="top">Email<br /></td>
                  </tr>
                  <tr>
                    <td width="50%" align="left" valign="top"><p>Indian Journal of Spatial Science<br />
                      Department of Geography,<br />
                      Presidency University (formerly College),<br />
                      86/1, College Street,<br />
                      Kolkata - 700 073 <br />
                      Ph. : + 91 33 2241 1960 (Extn. 206) <br />
                      Fax: +91 33 2241 2738, +91 33 2257 2444</p>
<p>or</p>
                      <p>&quot;Sumangal&quot;<br />
                        47 Bosepara Road<br />
                        P.O. – Chandannagar, <br />
                        Dist. – Hooghly<br />
                        West Bengal, India<br />
                    PIN – 712 136</p></td>
                    <td width="50%" align="left" valign="top"><p>editorijss2012@gmail.com</p>
<p>profdrashis@gmail.com</p>
                      <p>etraverse.ijss@gmail.com</p>
                    <p>etraverse.ijss@gmail.com</p></td>
                  </tr>
                </table>
												
                
                </div>
             
            </div>
           
            
            
            <!--footer portion-->
		<?php $this->load->view('include/footer');?>
        	<!--end footer portion-->