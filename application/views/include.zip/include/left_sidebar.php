            <!--left sidebar-->
            <div id="left_col">
            <img src="<?php echo base_url(); ?>assats/looks/images/left_col_icon.png" width="98" height="141" style="margin-bottom:20px;" />
            <img src="<?php echo base_url(); ?>assats/looks/images/current_issue.png" width="201" height="41" alt="current_issue" style="margin-bottom:15px;" />
            <div class="inner_left">Workplace Culture & Status of Women Construction Labourers: a case study in Kolkata, West Bengal.            
<span style="float:right">-Anu Rai, Prof Ashis Sarkar</span>            
            </div>
<div class="inner_text">
            	The construction sector has the largest number of unorganized labourers in India next only to the agricultural sector, and women form almost half the workforce as unskilled labourers with no occupational mobility. Often they face serious problems/constraints related to work, viz., lack of continuity, insecurity, wage discrimination, gender and sexual harassment, unhealthy job relationship, lower wages, and poor job satisfaction Despite these, construction industry verwhelmingly attracts female workers. Poverty being the main cause, the worst affected are the single and the derelict / destitute women with children to support... <br /><br />
		
            <span class="read_more"><a href="#">Read More</a></span><br />
         
            </div>
            </div>
            <!--left sidebar end-->
