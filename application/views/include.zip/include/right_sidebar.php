            <!--Total right sidebar-->
            <div class="right_article"><img src="<?php echo base_url(); ?>assats/looks/images/publication_archive.png" width="202" height="27" alt="Publication" />
              <ul style="list-style:none; margin:0; padding:5px 10px 10px 20px; text-align:left; line-height:21px;">
            	<li><a href="#" style="color:#0a546a">www.aag.org</a></li>
                <li><a href="#" style="color:#0a546a">www.rdgs.dk</a></li>
                <li><a href="#" style="color:#0a546a">www.ccsenet.org</a></li>
                <li><a href="#" style="color:#0a546a">www.springer.com</a></li>
                <li><a href="#" style="color:#0a546a">www.iosrjournals.org</a></li>
                <li><a href="#" style="color:#0a546a">www.omicsgroup.org</a></li>
                <li><a href="#" style="color:#0a546a">www.tandfonline.com</a></li>
                <li><a href="#" style="color:#0a546a">www.academicjournals.org</a></li>
                <li><a href="#" style="color:#0a546a">www.onlinelibrary.wiley.com</a></li>
                <li><a href="#" style="color:#0a546a">www.antipodefoundation.org</a></li>
                <li><a href="#" style="color:#0a546a">www.myncge.bravehearts.com</a></li>
                <li><a href="#" style="color:#0a546a">www.eurogeographyjournal.eu</a></li>
            </ul>
            </div>
            <div id="right_col">
       	    <img src="<?php echo base_url(); ?>assats/looks/images/related_site.png" width="202" height="27" alt="Related Site" />
            <ul>
            	<?php if(isset($sidebar_links)): ?>
                	<?php foreach($sidebar_links as $link):?>
            			<li><a href="<?php echo $link->url; ?>" target="_blank"><?php echo $link->title; ?></a></li>
                    <?php endforeach; ?>
                <?php endif; ?>
                <!--www.aag.org<li><a href="#" style="color:#0a546a">www.rdgs.dk</a></li>
                <li><a href="#" style="color:#0a546a">www.ccsenet.org</a></li>
                <li><a href="#" style="color:#0a546a">www.springer.com</a></li>
                <li><a href="#" style="color:#0a546a">www.iosrjournals.org</a></li>
                <li><a href="#" style="color:#0a546a">www.omicsgroup.org</a></li>
                <li><a href="#" style="color:#0a546a">www.tandfonline.com</a></li>
                <li><a href="#" style="color:#0a546a">www.academicjournals.org</a></li>
                <li><a href="#" style="color:#0a546a">www.onlinelibrary.wiley.com</a></li>
                <li><a href="#" style="color:#0a546a">www.antipodefoundation.org</a></li>
                <li><a href="#" style="color:#0a546a">www.myncge.bravehearts.com</a></li>
                <li><a href="#" style="color:#0a546a">www.eurogeographyjournal.eu</a></li>-->
            </ul>
            </div>
            <!--Total right sidebar end-->
